package com.jsongo.mobileim.imui.listener;

import com.jsongo.campusmessager.imchatui.MessageUtil;
import com.jsongo.core.network.ApiManager;
import com.jsongo.core.widget.RxToast;
import com.jsongo.mobileim.bean.Message;
import com.jsongo.mobileim.imui.ChatActivity;
import com.jsongo.mobileim.imui.ChatMessage;
import com.jsongo.mobileim.operator.ChatMessageSender;

import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.io.File;
import java.util.List;

import cn.jiguang.imui.chatinput.listener.OnCameraCallbackListener;
import cn.jiguang.imui.commons.models.IMessage;
import cn.jiguang.imui.messages.MsgListAdapter;
import io.reactivex.disposables.CompositeDisposable;

/**
 * @author jsongo
 * @date 2019/3/10 15:38
 */
public class CameraCallbackListener implements OnCameraCallbackListener {

    private final ChatActivity chatActivity;
    //    private final ChatView chatView;
    private final MsgListAdapter<ChatMessage> msgListAdapter;
    private final List<String> imagePathList;
    private final List<String> imgMsgIdList;
    private final FileEngine fileEngine = NetEngine.getEngine(FileEngine.class);
    private CompositeDisposable compositeDisposable = new CompositeDisposable();

    public CameraCallbackListener(ChatActivity chatActivity) {
        this.chatActivity = chatActivity;
//        this.chatView = chatActivity.getChatView();
        this.msgListAdapter = chatActivity.getMsgListAdapter();
        imagePathList = chatActivity.getImagePathList();
        imgMsgIdList = chatActivity.getImgMsgIdList();
    }

    @Override
    public void onTakePictureCompleted(String photoPath) {
        Message message = new Message(0, MessageUtil.INSTANCE.genUUID(),
                MyApplication.user.getChat_id(), Message.TYPE_IMAGE, "",
                UtilKt.currentTimeStamp(), chatActivity.getConv_id(),
                false, MyApplication.user);
        message.setType(Message.TYPE_IMAGE);
        message.setFilePath(photoPath);
        ChatMessage chatMessage = MessageUtil.INSTANCE.messageToChatMessage(message);

        fileEngine.uploadImage(compositeDisposable, new File(photoPath), true, new ApiCallback<String>() {
            @Override
            public void onSuccess(String url) {
                message.setFilePath(url);
                message.setContent(url);
                chatMessage.setMediaFilePath(ApiManager.INSTANCE.getBaseUrl() + url);

                ChatMessageSender.sendMessageAsync(message,
                        chatActivity.getAimChatUser().getId(),
                        new SendCallback() {
                            @Override
                            public void onSuccess() {
                                imagePathList.add(ApiManager.INSTANCE.getBaseUrl() + url);
                                imgMsgIdList.add(message.getMsg_id());
                                chatMessage.setMessageStatus(IMessage.MessageStatus.SEND_SUCCEED);
                                msgListAdapter.updateMessage(chatMessage);
                            }

                            @Override
                            public void onFailed() {
                                chatMessage.setMessageStatus(IMessage.MessageStatus.SEND_FAILED);
                                msgListAdapter.updateMessage(chatMessage);
                            }
                        });
            }

            @Override
            public void onFailed(int code, @NotNull String msg, @Nullable Object obj) {
                chatMessage.setMessageStatus(IMessage.MessageStatus.SEND_FAILED);
                msgListAdapter.updateMessage(chatMessage);
            }
        });
        chatActivity.runOnUiThread(() -> msgListAdapter.addToStart(chatMessage, true));
    }

    @Override
    public void onStartVideoRecord() {
        RxToast.info("onStartVideoRecord");
    }

    /**
     * 视频录制完成后触发，发送视频是在onSendFiles方法中
     *
     * @param videoPath
     */
    @Override
    public void onFinishVideoRecord(String videoPath) {
    }

    @Override
    public void onCancelVideoRecord() {
        RxToast.info("onCancelVideoRecord");
    }

    public void disposable() {
        compositeDisposable.dispose();
    }
}

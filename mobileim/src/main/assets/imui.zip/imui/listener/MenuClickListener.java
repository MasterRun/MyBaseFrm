package com.jsongo.mobileim.imui.listener;

import android.Manifest;
import android.content.pm.PackageManager;

import androidx.core.content.ContextCompat;

import com.jsongo.campusmessager.imchatui.MessageUtil;
import com.jsongo.core.network.ApiManager;
import com.jsongo.core.widget.RxToast;
import com.jsongo.mobileim.bean.Message;
import com.jsongo.mobileim.imui.ChatActivity;
import com.jsongo.mobileim.imui.ChatMessage;
import com.jsongo.mobileim.imui.ChatView;
import com.jsongo.mobileim.operator.ChatMessageSender;
import com.tbruyelle.rxpermissions2.RxPermissions;

import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.io.File;
import java.util.List;

import cn.jiguang.imui.chatinput.listener.OnMenuClickListener;
import cn.jiguang.imui.chatinput.model.FileItem;
import cn.jiguang.imui.chatinput.model.VideoItem;
import cn.jiguang.imui.commons.models.IMessage;
import cn.jiguang.imui.messages.MsgListAdapter;
import io.reactivex.disposables.CompositeDisposable;
import io.reactivex.disposables.Disposable;

/**
 * @author jsongo
 * @date 2019/3/10 15:25
 */
public class MenuClickListener implements OnMenuClickListener {

    private final ChatActivity chatActivity;
    private final ChatView chatView;
    private final MsgListAdapter<ChatMessage> msgListAdapter;
    private final RxPermissions rxPermissions;
    private final List<String> imagePathList;
    private final List<String> imgMsgIdList;
    private final CompositeDisposable compositeDisposable = new CompositeDisposable();
    private final FileEngine fileEngine = NetEngine.getEngine(FileEngine.class);

    public MenuClickListener(ChatActivity chatActivity) {
        this.chatActivity = chatActivity;
        this.msgListAdapter = chatActivity.getMsgListAdapter();
        this.chatView = chatActivity.getChatView();
        rxPermissions = new RxPermissions(chatActivity);
        imagePathList = chatActivity.getImagePathList();
        imgMsgIdList = chatActivity.getImgMsgIdList();
    }

    @Override
    public boolean onSendTextMessage(CharSequence input) {
        if (input.length() == 0) {
            return false;
        }
        if (input.length() > 140) {
            RxToast.warning("暂不支持发送大文本！");
            return false;
        }
        Message message = new Message(0, MessageUtil.INSTANCE.genUUID(),
                MyApplication.user.getChat_id(),
                Message.TYPE_TEXT, input.toString(),
                UtilKt.currentTimeStamp(), chatActivity.getConv_id(),
                false, MyApplication.user);
        ChatMessage chatMessage = MessageUtil.INSTANCE.messageToChatMessage(message);
        msgListAdapter.addToStart(chatMessage, true);
        ChatMessageSender.sendMessageAsync(message, chatActivity.getAimChatUser().getId(), new SendCallback() {
            @Override
            public void onSuccess() {
                LogUtilKt.loge(MenuClickListener.class, "发送成功");
                chatMessage.setMessageStatus(IMessage.MessageStatus.SEND_SUCCEED);
                msgListAdapter.updateMessage(chatMessage);
            }

            @Override
            public void onFailed() {
                LogUtilKt.loge(MenuClickListener.class, "发送失败");
                chatMessage.setMessageStatus(IMessage.MessageStatus.SEND_FAILED);
                msgListAdapter.updateMessage(chatMessage);
            }
        });
        return true;
    }

    @Override
    public void onSendFiles(List<FileItem> list) {
        if (list == null || list.isEmpty()) {
            return;
        }
        for (FileItem item : list) {
            String msgId = MessageUtil.INSTANCE.genUUID();
            Message message = new Message(0, msgId, MyApplication.user.getChat_id(),
                    Message.TYPE_IMAGE, "", UtilKt.currentTimeStamp(),
                    chatActivity.getConv_id(), false, MyApplication.user);
            message.setFilePath(item.getFilePath());
            ChatMessage chatMessage = MessageUtil.INSTANCE.messageToChatMessage(message);
            if (item.getType() == FileItem.Type.Image) {
                message.setType(Message.TYPE_IMAGE);
                chatMessage.setType(IMessage.MessageType.SEND_IMAGE.ordinal());

                fileEngine.uploadImage(compositeDisposable, new File(item.getFilePath()), true, new ApiCallback<String>() {
                    @Override
                    public void onSuccess(String url) {
                        message.setFilePath(url);
                        message.setContent(url);
                        chatMessage.setMediaFilePath(ApiManager.INSTANCE.getBaseUrl() + url);

                        ChatMessageSender.sendMessageAsync(message,
                                chatActivity.getAimChatUser().getId(),
                                new SendCallback() {
                                    @Override
                                    public void onSuccess() {
                                        imagePathList.add(ApiManager.INSTANCE.getBaseUrl() + url);
                                        imgMsgIdList.add(msgId);
                                        chatMessage.setMessageStatus(IMessage.MessageStatus.SEND_SUCCEED);
                                        msgListAdapter.updateMessage(chatMessage);
                                    }

                                    @Override
                                    public void onFailed() {
                                        chatMessage.setMessageStatus(IMessage.MessageStatus.SEND_FAILED);
                                        msgListAdapter.updateMessage(chatMessage);
                                    }
                                });
                    }

                    @Override
                    public void onFailed(int code, @NotNull String msg, @Nullable Object obj) {
                        chatMessage.setMessageStatus(IMessage.MessageStatus.SEND_FAILED);
                        msgListAdapter.updateMessage(chatMessage);
                    }
                });
            } else if (item.getType() == FileItem.Type.Video) {
                message.setType(Message.TYPE_VIDEO);
                chatMessage.setType(IMessage.MessageType.SEND_VIDEO.ordinal());
                chatMessage.setDuration(((VideoItem) item).getDuration());
                fileEngine.uploadChatVideo(compositeDisposable, new File(item.getFilePath()), new ApiCallback<String>() {
                    @Override
                    public void onSuccess(String url) {
                        message.setContent(url);

                        ChatMessageSender.sendMessageAsync(message,
                                chatActivity.getAimChatUser().getId(), new SendCallback() {
                                    @Override
                                    public void onSuccess() {
                                        chatMessage.setMessageStatus(IMessage.MessageStatus.SEND_SUCCEED);
                                        msgListAdapter.updateMessage(chatMessage);
                                    }

                                    @Override
                                    public void onFailed() {
                                        chatMessage.setMessageStatus(IMessage.MessageStatus.SEND_FAILED);
                                        msgListAdapter.updateMessage(chatMessage);
                                    }
                                });
                    }

                    @Override
                    public void onFailed(int code, @NotNull String msg, @Nullable Object obj) {
                        chatMessage.setMessageStatus(IMessage.MessageStatus.SEND_FAILED);
                        msgListAdapter.updateMessage(chatMessage);
                    }
                });
            } else {
                throw new RuntimeException("Invalid FileItem type. Must be Type.Image or Type.Video");
            }
            chatActivity.runOnUiThread(() -> msgListAdapter.addToStart(chatMessage, true));
        }
    }

    @Override
    public boolean switchToMicrophoneMode() {
        chatView.scrollToBottom();
        String[] permissions = new String[]{
                Manifest.permission.RECORD_AUDIO,
                Manifest.permission.WRITE_EXTERNAL_STORAGE
        };

        Disposable disposable = rxPermissions.request(permissions).subscribe(granted -> {
            if (!granted) {
                RxToast.error("无法使用录音机");
            }
        });
        compositeDisposable.add(disposable);
        return true;
    }

    @Override
    public boolean switchToGalleryMode() {
        chatView.scrollToBottom();
        String[] permissions = new String[]{
                Manifest.permission.READ_EXTERNAL_STORAGE
        };
        Disposable disposable = rxPermissions.request(permissions).subscribe();
        compositeDisposable.add(disposable);

        // If you call updateData, select photo view will try to update data(Last update over 30 seconds.)
        chatView.getChatInputView().getSelectPhotoView().updateData();
        return true;
    }

    @Override
    public boolean switchToCameraMode() {
        chatView.scrollToBottom();
        String[] perms = new String[]{
                Manifest.permission.WRITE_EXTERNAL_STORAGE,
                Manifest.permission.CAMERA,
                Manifest.permission.RECORD_AUDIO
        };
        boolean granted = true;
        for (String perm : perms) {
            if (ContextCompat.checkSelfPermission(chatActivity, perm) != PackageManager.PERMISSION_GRANTED) {
                granted = false;
                break;
            }
        }
        if (!granted) {
            Disposable disposable = rxPermissions.request(perms).subscribe();
            compositeDisposable.add(disposable);
            return false;
        }
        return true;
    }

    @Override
    public boolean switchToEmojiMode() {
        chatView.scrollToBottom();
        return true;
    }

    public void dispose() {
        compositeDisposable.dispose();
    }
}

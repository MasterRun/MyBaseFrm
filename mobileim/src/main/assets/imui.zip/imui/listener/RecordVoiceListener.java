package com.jsongo.mobileim.imui.listener;

import android.text.format.DateFormat;

import com.jsongo.campusmessager.imchatui.MessageUtil;
import com.jsongo.mobileim.bean.Message;
import com.jsongo.mobileim.imui.ChatActivity;
import com.jsongo.mobileim.imui.ChatMessage;
import com.jsongo.mobileim.imui.ChatView;
import com.jsongo.mobileim.operator.ChatMessageSender;

import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.io.File;
import java.util.Calendar;
import java.util.Locale;

import cn.jiguang.imui.commons.models.IMessage;
import cn.jiguang.imui.messages.MsgListAdapter;
import io.reactivex.disposables.CompositeDisposable;

/**
 * @author jsongo
 * @date 2019/3/10 15:36
 */
public class RecordVoiceListener implements cn.jiguang.imui.chatinput.listener.RecordVoiceListener {

    private final ChatActivity chatActivity;
    private final ChatView chatView;
    private final MsgListAdapter<ChatMessage> msgListAdapter;
    private final FileEngine fileEngine = NetEngine.getEngine(FileEngine.class);
    private CompositeDisposable compositeDisposable = new CompositeDisposable();

    public RecordVoiceListener(ChatActivity chatActivity) {
        this.chatActivity = chatActivity;
        this.chatView = chatActivity.getChatView();
        this.msgListAdapter = chatActivity.getMsgListAdapter();
    }

    @Override
    public void onStartRecord() {
        // set voice file path, after recording, audio file will save here
        String path = SubUrl.getExternal_audio_path();
        File destDir = new File(path);
        if (!destDir.exists()) {
            destDir.mkdirs();
        }
        chatView.setRecordVoiceFile(destDir.getPath(),
                DateFormat.format("yyyy-MM-dd-hhmmss", Calendar.getInstance(Locale.CHINA)) + "");
    }

    @Override
    public void onFinishRecord(File voiceFile, int duration) {
        Message message = new Message(0, MessageUtil.INSTANCE.genUUID(),
                MyApplication.user.getChat_id(), Message.TYPE_AUDIO, "",
                UtilKt.currentTimeStamp(), chatActivity.getConv_id(),
                false, MyApplication.user);
        message.setFilePath(voiceFile.getAbsolutePath());
        ChatMessage chatMessage = MessageUtil.INSTANCE.messageToChatMessage(message);
        chatMessage.setDuration(duration);
        fileEngine.uploadChatAudio(compositeDisposable, voiceFile, new ApiCallback<String>() {
            @Override
            public void onSuccess(String url) {
                message.setContent(url);
                ChatMessageSender.sendMessageAsync(message, chatActivity.getAimChatUser().getId(),
                        new SendCallback() {
                            @Override
                            public void onSuccess() {
                                chatMessage.setMessageStatus(IMessage.MessageStatus.SEND_SUCCEED);
                                msgListAdapter.updateMessage(chatMessage);
                            }

                            @Override
                            public void onFailed() {
                                chatMessage.setMessageStatus(IMessage.MessageStatus.SEND_FAILED);
                                msgListAdapter.updateMessage(chatMessage);
                            }
                        });
            }

            @Override
            public void onFailed(int code, @NotNull String msg, @Nullable Object obj) {
                chatMessage.setMessageStatus(IMessage.MessageStatus.SEND_FAILED);
                msgListAdapter.updateMessage(chatMessage);
            }
        });
        msgListAdapter.addToStart(chatMessage, true);
    }

    @Override
    public void onCancelRecord() {
        // 录音取消
    }

    /**
     * In preview record voice layout, fires when click cancel button
     * Add since chatinput v0.7.3
     */
    @Override
    public void onPreviewCancel() {

    }

    /**
     * In preview record voice layout, fires when click send button
     * Add since chatinput v0.7.3
     */
    @Override
    public void onPreviewSend() {

    }

    public void disposable() {
        compositeDisposable.dispose();
    }
}

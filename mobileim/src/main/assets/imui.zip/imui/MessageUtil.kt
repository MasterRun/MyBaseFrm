package com.jsongo.campusmessager.imchatui

import android.text.TextUtils
import cn.jiguang.imui.commons.models.IMessage
import com.jsongo.campusmessager.MyApplication
import com.jsongo.campusmessager.bean.Message
import com.jsongo.campusmessager.network.ApiManager
import com.jsongo.campusmessager.util.relativeTime


import java.util.*
import kotlin.collections.ArrayList

/**
 * @author  jsongo
 * @date 2019/3/9 16:01
 */
object MessageUtil {

    fun genUUID() = UUID.randomUUID().toString().replace("-", "")

/*   fun chatMessageToMessage(chatMessage: ChatMessage): Message? {
        var content = if (TextUtils.isEmpty(chatMessage.text)) chatMessage.mediaFilePath else chatMessage.text
       val type = chatMessageTypeToMessageType(chatMessage.type)
       var message = Message(chatMessage.msgId.toLong(), chatMessage.fromUser.id,
               type,content,
               )

       return chatMessage.message
   }*/

    fun messageToChatMessage(message: Message) = MessageUtil.messageToChatMessage(message, null)

    fun messageToChatMessage(message: Message, chatUser: ChatUser?): ChatMessage {
        val sender_id = message.sender_id
        val sender = message.sender
        val aimChatUser: ChatUser
        val localuser = MyApplication.user
        if (localuser != null && sender_id == localuser.chat_id) {
            aimChatUser = ChatUser(localuser.chat_id, localuser.nickname, localuser.avatar)
        } else if (chatUser != null) {
            aimChatUser = chatUser
        } else if (sender != null) {
            aimChatUser = ChatUser(sender.chat_id, sender.nickname, sender.avatar)
        } else {
            throw Exception("sender is null ")
        }
        val type = messageTypeToChatMessageType(message)
        val chatMessage = ChatMessage(message.msg_id, aimChatUser, type, relativeTime(message.send_time))
        when (message.type) {
            Message.TYPE_TEXT -> chatMessage.text = message.content
            Message.TYPE_IMAGE -> {
                if (TextUtils.isEmpty(message.content)) {
                    chatMessage.mediaFilePath = message.filePath
                } else {
                    chatMessage.mediaFilePath = ApiManager.baseUrl + message.content
                }
            }
            Message.TYPE_AUDIO -> chatMessage.mediaFilePath = message.filePath

            Message.TYPE_VIDEO -> chatMessage.mediaFilePath = message.filePath


            // TODO: 2019/3/16
        }
//        chatMessage.text = message.content
//        chatMessage.mediaFilePath = message.filePath
        chatMessage.message = message
        return chatMessage
    }

    fun messagesToChatMessages(messages: List<Message>, chatUser: ChatUser?): List<ChatMessage> {
        val chatmessages = ArrayList<ChatMessage>()
        for (message in messages) {
            val chatMessage = MessageUtil.messageToChatMessage(message, chatUser)
            if (chatMessage.fromUser.id.equals(MyApplication.user.chat_id)) {
                chatMessage.setMessageStatus(IMessage.MessageStatus.SEND_SUCCEED)
            } else {
                chatMessage.setMessageStatus(IMessage.MessageStatus.RECEIVE_SUCCEED)
            }
            chatmessages.add(chatMessage)
        }
        return chatmessages
    }

    fun messageTypeToChatMessageType(message: Message) =
            when (message.type) {
                Message.TYPE_TEXT ->
                    if (MyApplication.user.chat_id == message.sender_id) {
                        IMessage.MessageType.SEND_TEXT.ordinal
                    } else {
                        IMessage.MessageType.RECEIVE_TEXT.ordinal
                    }
                Message.TYPE_AUDIO ->
                    if (MyApplication.user.chat_id == message.sender_id) {
                        IMessage.MessageType.SEND_VOICE.ordinal
                    } else {
                        IMessage.MessageType.RECEIVE_VOICE.ordinal
                    }
                Message.TYPE_FILE ->
                    if (MyApplication.user.chat_id == message.sender_id) {
                        IMessage.MessageType.SEND_FILE.ordinal
                    } else {
                        IMessage.MessageType.RECEIVE_FILE.ordinal
                    }
                Message.TYPE_IMAGE ->
                    if (MyApplication.user.chat_id == message.sender_id) {
                        IMessage.MessageType.SEND_IMAGE.ordinal
                    } else {
                        IMessage.MessageType.RECEIVE_IMAGE.ordinal
                    }
                Message.TYPE_VIDEO ->
                    if (MyApplication.user.chat_id == message.sender_id) {
                        IMessage.MessageType.SEND_VIDEO.ordinal
                    } else {
                        IMessage.MessageType.RECEIVE_VIDEO.ordinal
                    }
                else -> IMessage.MessageType.SEND_TEXT.ordinal

            }

    fun chatMessageTypeToMessageType(type: Int) =
            when (type) {
                IMessage.MessageType.RECEIVE_TEXT.ordinal -> Message.TYPE_TEXT
                IMessage.MessageType.SEND_TEXT.ordinal -> Message.TYPE_TEXT
                IMessage.MessageType.RECEIVE_IMAGE.ordinal -> Message.TYPE_IMAGE
                IMessage.MessageType.SEND_IMAGE.ordinal -> Message.TYPE_IMAGE
                IMessage.MessageType.RECEIVE_VOICE.ordinal -> Message.TYPE_AUDIO
                IMessage.MessageType.SEND_VOICE.ordinal -> Message.TYPE_AUDIO
                IMessage.MessageType.RECEIVE_VIDEO.ordinal -> Message.TYPE_VIDEO
                IMessage.MessageType.SEND_VIDEO.ordinal -> Message.TYPE_VIDEO
                IMessage.MessageType.RECEIVE_FILE.ordinal -> Message.TYPE_FILE
                IMessage.MessageType.SEND_FILE.ordinal -> Message.TYPE_FILE
                else -> -1
            }

}
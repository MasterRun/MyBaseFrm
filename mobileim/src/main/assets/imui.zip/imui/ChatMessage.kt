package com.jsongo.mobileim.imui

import cn.jiguang.imui.commons.models.IMessage
import cn.jiguang.imui.commons.models.IUser
import com.jsongo.mobileim.bean.Message

/**
 * @author jsongo
 * @date 2019/3/8 19:54
 */
data class ChatMessage
constructor(
    private var msgId: String = "",
    private var fromUser: IUser,
    private var type: Int = IMessage.MessageType.SEND_TEXT.ordinal,
    private var timeString: String = ""
) : IMessage {

    var message: Message? = null

    private var messageStatus: IMessage.MessageStatus = IMessage.MessageStatus.SEND_GOING
    private var text: String = ""
    private var duration: Long = 0
    private var progress: String = ""
    private var mediaFilePath: String = ""
    private var extras: HashMap<String, String>? = null

    override fun getMsgId(): String = msgId

    fun setMsgId(msgId: String) {
        this.msgId = msgId
    }

    override fun getFromUser(): IUser = fromUser

    fun setFromUser(fromUser: IUser) {
        this.fromUser = fromUser
    }

    override fun getMessageStatus(): IMessage.MessageStatus? = messageStatus

    fun setMessageStatus(messageStatus: IMessage.MessageStatus) {
        this.messageStatus = messageStatus
    }

    override fun getDuration(): Long = duration

    fun setDuration(duration: Long) {
        this.duration = duration
    }

    override fun getExtras(): HashMap<String, String>? = extras

    fun setExtras(extras: HashMap<String, String>) {
        this.extras = extras
    }

    override fun getType(): Int = type

    fun setType(type: Int) {
        this.type = type
    }

    override fun getText(): String = text

    fun setText(text: String) {
        this.text = text
    }

    override fun getProgress(): String = progress

    fun setProgress(progress: String) {
        this.progress = progress
    }

    override fun getMediaFilePath(): String = mediaFilePath

    fun setMediaFilePath(mediaFilePath: String) {
        this.mediaFilePath = mediaFilePath
    }

    override fun getTimeString(): String = timeString

    fun setTimeString(timeString: String) {
        this.timeString = timeString
    }
}

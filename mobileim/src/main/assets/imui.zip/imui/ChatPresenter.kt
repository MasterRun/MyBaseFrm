package com.jsongo.mobileim.imui

import android.media.MediaPlayer
import cn.jiguang.imui.commons.models.IMessage
import com.jsongo.campusmessager.MyApplication
import com.jsongo.campusmessager.bean.Conversation
import com.jsongo.campusmessager.bean.Message
import com.jsongo.campusmessager.imchatui.ChatMessage
import com.jsongo.campusmessager.imchatui.ChatUser
import com.jsongo.campusmessager.imchatui.MessageUtil
import com.jsongo.campusmessager.mobileim.operator.ChatMessageSender
import com.jsongo.campusmessager.mobileim.operator.SendCallback
import com.jsongo.campusmessager.model.ChatModel
import com.jsongo.campusmessager.mvp.IChat
import com.jsongo.campusmessager.mvp.base.BasePresenter
import com.jsongo.campusmessager.network.ApiCallback
import com.jsongo.campusmessager.network.ApiManager
import com.jsongo.campusmessager.network.SubUrl
import com.jsongo.campusmessager.util.BusEvent
import com.jsongo.campusmessager.util.RxBus
import com.jsongo.campusmessager.util.currentTimeStamp
import com.jsongo.campusmessager.util.loge
import com.vondear.rxtool.view.RxToast
import io.reactivex.Observable
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.schedulers.Schedulers
import java.io.File
import java.io.IOException
import java.util.*
import java.util.concurrent.TimeUnit

/**
 * @author  jsongo
 * @date 2019/4/3 21:09
 * @desc  聊天 presenter
 */
class ChatPresenter
(view: IChat.IView, conv_id: String, val aimChatUser: ChatUser)
    : BasePresenter<IChat.IModel, IChat.IView>(view),
        IChat.IPresenter<IChat.IModel, IChat.IView> {
    override val model: IChat.IModel
    private var pageIndex = 0
    private var conversation: Conversation? = null
    override val imgMsgIdList = ArrayList<String>()
    override val imagePathList = ArrayList<String>()
    override var conv_id: String = ""

    init {
        model = ChatModel()
        this.conv_id = conv_id
    }

    override fun start() {
        registerEvent()
        pageIndex = 0
        getConv()
    }

    private fun getConv() {
        model.getConv(MyApplication.user.chat_id, aimChatUser.id, object : ApiCallback<Conversation> {
            override fun onSuccess(t: Conversation) {
                conversation = t
                conv_id = t.conv_id
                loadMessage()
            }

            override fun onFailed(code: Int, msg: String, obj: Any?) {
                RxToast.error(msg)
            }
        })
    }

    override fun setConversationRead() {
        model.setConversationRead(conv_id)
    }

    private fun loadMessage() {
        model.getMessages(conv_id, pageIndex + 1, object : ApiCallback<List<Message>> {
            override fun onSuccess(t: List<Message>) {
                setConversationRead()
                view?.refreshComplete()
                if (t.size == 0) {
                    if (pageIndex == 0) {
                        return
                    } else if (pageIndex > 0) {
                        RxToast.info("没有了...")
                        return
                    }
                }
                pageIndex++
                val disposable = Observable.fromIterable(t)
                        .map { message ->
                            /*switch (message.getType()) {
                        case Message.TYPE_AUDIO:
                            String content = message.getContent();
                            String[] split = content.split("/");
                            String filename = split[split.length - 1];
                            File audioFile = new File(SubUrl.getExternal_audio_path(), filename);
                            if (audioFile.exists()) {
                                message.setFilePath(audioFile.getAbsolutePath());
                            } else {

                            }
                            break;
                        case Message.TYPE_VIDEO:
                            break;
                        default:
                    }*/
                            if (message.type == Message.TYPE_IMAGE) {
                                imgMsgIdList.add(0, message.msg_id)
                                imagePathList.add(0, ApiManager.baseUrl + message.content)
                            }
                            val chatMessage = MessageUtil.messageToChatMessage(message, aimChatUser)
                            if (chatMessage.fromUser.id == MyApplication.user.chat_id) {
                                chatMessage.setMessageStatus(IMessage.MessageStatus.SEND_SUCCEED)
                            } else {
                                chatMessage.setMessageStatus(IMessage.MessageStatus.RECEIVE_SUCCEED)
                            }
                            chatMessage
                        }
                        .toList()
                        .subscribeOn(Schedulers.io())
                        .observeOn(AndroidSchedulers.mainThread())
                        .subscribe { chatMessages ->
                            if (pageIndex == 1) {
                                view?.scrollToBottom()
                            } else {
                                RxToast.normal("加载完成")
                            }
                            view?.addToEnd(chatMessages)
                        }
                addDisposable(disposable)
            }

            override fun onFailed(code: Int, msg: String, obj: Any?) {
                RxToast.error(msg)
            }
        })
    }


    /**
     * 监听收到udp消息
     */
    private fun registerEvent() {
        class MediaFileCallback(var message: Message, var chatMessage: ChatMessage) : ApiCallback<File> {

            override fun onSuccess(t: File) {
                message.filePath = t.absolutePath
                chatMessage.mediaFilePath = t.absolutePath
                try {
                    var mediaPlayer: MediaPlayer? = MediaPlayer()
                    mediaPlayer!!.setDataSource(t.path)
                    mediaPlayer.prepare()
                    val duration = mediaPlayer.duration
                    chatMessage.duration = (duration / 1000).toLong()
                    mediaPlayer.release()
                    mediaPlayer = null
                    chatMessage.setMessageStatus(IMessage.MessageStatus.RECEIVE_SUCCEED)
                    view?.updateMessage(chatMessage)
                } catch (e: IOException) {
                    e.printStackTrace()
                    onFailed(0, "media error", e)
                }

            }

            override fun onFailed(code: Int, msg: String, obj: Any?) {
                chatMessage.setMessageStatus(IMessage.MessageStatus.RECEIVE_FAILED)
                view?.updateMessage(chatMessage)
            }
        }

        val disposable = RxBus.toFlowable()
                .filter { event ->
                    event.code == BusEvent.Code_MessageFromUdp && event.data is Message
                }
                .map<ChatMessage> { event ->
                    val message = event.data as Message
                    loge(ChatPresenter::class.java, message.toString())
                    var chatMessage: ChatMessage? = null
                    if (message.sender_id == aimChatUser.getId()) {
                        chatMessage = MessageUtil.messageToChatMessage(message, aimChatUser)
                        if (message.type == Message.TYPE_IMAGE) {
                            imgMsgIdList.add(message.msg_id)
                            imagePathList.add(ApiManager.baseUrl + message.content)
                        } else if (message.type == Message.TYPE_AUDIO) {
                            chatMessage.setMessageStatus(IMessage.MessageStatus.RECEIVE_GOING)
                            val mediaFileCallback = MediaFileCallback(message, chatMessage)
                            model.downloadFile(ApiManager.baseUrl + message.content, SubUrl.external_audio_path, mediaFileCallback)
                        } else if (message.type == Message.TYPE_VIDEO) {
                            chatMessage.setMessageStatus(IMessage.MessageStatus.RECEIVE_GOING)
                            val mediaFileCallback = MediaFileCallback(message, chatMessage)
                            model.downloadFile(ApiManager.baseUrl + message.content, SubUrl.external_video_path, mediaFileCallback)
                        }
                    }
                    chatMessage
                }
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe({ chatMessage ->
                    if (chatMessage != null) {
                        view?.addMessageToStart(chatMessage)
                    }
                }, { t ->
                    loge(ChatMessage::class.java, t)
                })
        addDisposable(disposable)
    }

    override fun loadNextPage() {
        val disposable = Observable.timer(500, TimeUnit.MILLISECONDS)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe { aLong -> loadMessage() }
        addDisposable(disposable)
    }

    override fun uploadChatImages(resultPaths: List<String>) {
        if (resultPaths.size > 0) {
            for (resultPath in resultPaths) {
                val msgId = MessageUtil.genUUID()
                val message = Message(0, msgId, MyApplication.user.chat_id,
                        Message.TYPE_IMAGE, "", currentTimeStamp(),
                        conv_id, false, MyApplication.user)
                message.type = Message.TYPE_IMAGE
                message.filePath = resultPath
                val chatMessage = MessageUtil.messageToChatMessage(message)
                // TODO: 2019/4/3  这是异步，不保证发送顺序
                uploadChatImage(message, chatMessage, resultPath)
                view?.addMessageToStart(chatMessage)
            }
        }
    }

    fun uploadChatImage(message: Message, chatMessage: ChatMessage, resultPath: String) {
        model.uploadChatImage(File(resultPath), object : ApiCallback<String> {
            override fun onSuccess(url: String) {
                message.filePath = url
                message.content = url
                chatMessage.setMediaFilePath(ApiManager.baseUrl + url)
                //上传图片成功发送消息
                ChatMessageSender.sendMessageAsync(message, aimChatUser.getId(), object : SendCallback {
                    override fun onSuccess() {
                        imagePathList.add(ApiManager.baseUrl + url)
                        imgMsgIdList.add(message.msg_id)
                        chatMessage.setMessageStatus(IMessage.MessageStatus.SEND_SUCCEED)
                        view?.updateMessage(chatMessage)
                    }

                    override fun onFailed() {
                        chatMessage.setMessageStatus(IMessage.MessageStatus.SEND_FAILED)
                        view?.updateMessage(chatMessage)
                    }
                })
            }

            override fun onFailed(code: Int, msg: String, obj: Any?) {
                chatMessage.setMessageStatus(IMessage.MessageStatus.SEND_FAILED)
                view?.updateMessage(chatMessage)
            }
        })
    }

}
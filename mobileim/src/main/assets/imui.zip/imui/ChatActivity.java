package com.jsongo.mobileim.imui;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.media.AudioManager;
import android.os.PowerManager;
import android.view.MotionEvent;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;

import androidx.annotation.Nullable;

import com.huantansheng.easyphotos.EasyPhotos;
import com.jsongo.core.arch.BaseActivity;
import com.jsongo.core.widget.RxToast;
import com.jsongo.mobileim.R;
import com.jsongo.mobileim.imui.listener.CameraCallbackListener;
import com.jsongo.mobileim.imui.listener.MenuClickListener;
import com.jsongo.mobileim.imui.listener.RecordVoiceListener;
import com.jsongo.ui.component.image.preview.ImgPreviewClick;
import com.jsongo.ui.util.EasyPhotoGlideEngine;
import com.qmuiteam.qmui.util.QMUIStatusBarHelper;

import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;
import java.util.List;

import cn.jiguang.imui.chatinput.ChatInputView;
import cn.jiguang.imui.commons.models.IMessage;
import cn.jiguang.imui.messages.MsgListAdapter;
import cn.jiguang.imui.messages.ViewHolderController;
import cn.jiguang.imui.messages.ptr.PullToRefreshLayout;

public class ChatActivity extends BaseActivity implements SensorEventListener, View.OnTouchListener {

    @BindView(R.id.chat_view)
    ChatView chatView;

    @Autowired(name = RouterConst.conv_id)
    String conv_id = "";
    @Autowired(name = RouterConst.aimChatUser)
    ChatUser aimChatUser;
    private static final String TAG = "ChatActivity";
    private InputMethodManager inputMethodManager;
    private Window mWindow;
    private PowerManager mPowerManager;
    private PowerManager.WakeLock mWakeLock;
    private SensorManager mSensorManager;
    private Sensor mSensor;
    private MsgListAdapter<ChatMessage> msgListAdapter;
    private HeadsetDetectReceiver mReceiver;
    private int selectPhotoRequestCode = 1;
    private ChatInputView chatInputView;
    private MenuClickListener menuClickListener;
    private RecordVoiceListener recordVoiceListener;
    private CameraCallbackListener onCameraCallbackListener;
    private PullToRefreshLayout pullToRefreshLayout;

    public List<String> getImgMsgIdList() {
        return presenter.getImgMsgIdList();
    }

    public List<String> getImagePathList() {
        return presenter.getImagePathList();
    }

    public ChatView getChatView() {
        return chatView;
    }

    public String getConv_id() {
        return conv_id;
    }

    public ChatUser getAimChatUser() {
        return aimChatUser;
    }

    public MsgListAdapter<ChatMessage> getMsgListAdapter() {
        return msgListAdapter;
    }

    @Override
    public void setLayout() {
        setContentView(R.layout.activity_chat);
        ARouter.getInstance().inject(this);
    }

    @Override
    public void initView() {

        //todo activity返回时，设置标记，让上一activity设置消息已读

        QMUIStatusBarHelper.translucent(this);
//        QMUIStatusBarHelper.setStatusBarLightMode(this);

        inputMethodManager = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        mWindow = getWindow();
        registerProximitySensorListener();
        chatView.initModule();
        chatInputView = chatView.getChatInputView();
        chatView.getLeftBackImageButton().setOnClickListener((v) -> super.onBackPressed());
        chatView.setTitle(aimChatUser.getDisplayName());
        initMsgAdapter();
        mReceiver = new HeadsetDetectReceiver();
        IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction(Intent.ACTION_HEADSET_PLUG);
        registerReceiver(mReceiver, intentFilter);
        setClickListener();
    }

    private void setClickListener() {
        chatView.setOnTouchListener(this);
        menuClickListener = new MenuClickListener(this);
        chatView.setMenuClickListener(menuClickListener);

        recordVoiceListener = new RecordVoiceListener(this);
        chatView.setRecordVoiceListener(recordVoiceListener);

        onCameraCallbackListener = new CameraCallbackListener(this);
        chatView.setOnCameraCallbackListener(onCameraCallbackListener);

        chatInputView.getInputView().setOnTouchListener((view, motionEvent) -> {
            chatView.scrollToBottom();
            return false;
        });

        chatView.getSelectAlbumBtn().setOnClickListener(v ->
                EasyPhotos.createAlbum(ChatActivity.this, false,
                        EasyPhotoGlideEngine.getInstance())//参数说明：上下文，是否显示相机按钮，[配置Glide为图片加载引擎](https://github.com/HuanTanSheng/EasyPhotos/wiki/12-%E9%85%8D%E7%BD%AEImageEngine%EF%BC%8C%E6%94%AF%E6%8C%81%E6%89%80%E6%9C%89%E5%9B%BE%E7%89%87%E5%8A%A0%E8%BD%BD%E5%BA%93)
                        .setFileProviderAuthority(UtilKt.FILEPROVIDER_AUTHORITY)
                        .setCount(9)
                        .start(selectPhotoRequestCode));
    }

    private void initMsgAdapter() {
        // Use default layout
        MsgListAdapter.HoldersConfig holdersConfig = new MsgListAdapter.HoldersConfig();
        msgListAdapter = new MsgListAdapter<>(MyApplication.user.getChat_id(), holdersConfig, new IMUIImageLoader(this));
        msgListAdapter.setOnMsgClickListener(message -> {
            // do something
            if (message.getType() == IMessage.MessageType.RECEIVE_VIDEO.ordinal()
                    || message.getType() == IMessage.MessageType.SEND_VIDEO.ordinal()) {
/*                if (!TextUtils.isEmpty(message.getMediaFilePath())) {
                    Intent intent = new Intent(ChatActivity.this, VideoActivity.class);
                    intent.putExtra(VideoActivity.VIDEO_PATH, message.getMediaFilePath());
                    startActivity(intent);
                }*/
                RxToast.info("click video");
            } else if (message.getType() == IMessage.MessageType.RECEIVE_IMAGE.ordinal()
                    || message.getType() == IMessage.MessageType.SEND_IMAGE.ordinal()) {

                int i = presenter.getImgMsgIdList().indexOf(message.getMsgId());
                new ImgPreviewClick(this, i, presenter.getImagePathList()).start();
            } else {
                RxToast.info("message click");
            }
        });


        msgListAdapter.setMsgLongClickListener(new MsgListAdapter.OnMsgLongClickListener<ChatMessage>() {
            @Override
            public void onMessageLongClick(View view, ChatMessage message) {
                RxToast.info("onMessageLongClick : ");
/*                Toast.makeText(getApplicationContext(),
                        getApplicationContext().getString(R.string.message_long_click_hint),
                        Toast.LENGTH_SHORT).show();
                // do something*/
            }
        });

        msgListAdapter.setOnAvatarClickListener(new MsgListAdapter.OnAvatarClickListener<ChatMessage>() {
            @Override
            public void onAvatarClick(ChatMessage message) {
                UserDetailActivity.Companion.startThis(message.getFromUser().getId());
            }
        });

        msgListAdapter.setMsgStatusViewClickListener(new MsgListAdapter.OnMsgStatusViewClickListener<ChatMessage>() {
            @Override
            public void onStatusViewClick(ChatMessage message) {
                RxToast.info("onStatusViewClick");
                // message status view click, resend or download here
            }
        });

        pullToRefreshLayout = chatView.getPtrLayout();
        pullToRefreshLayout.setPtrHandler(refreshLayout -> presenter.loadNextPage());

        chatView.setAdapter(msgListAdapter);
        msgListAdapter.getLayoutManager().scrollToPosition(0);
    }

    @Override
    protected void onResume() {
        super.onResume();
    }

    @Override
    public void refreshComplete() {
        pullToRefreshLayout.refreshComplete();
    }

    @Override
    public void addMessageToStart(@NotNull ChatMessage chatMessage) {
        msgListAdapter.addToStart(chatMessage, true);
    }

    @Override
    public void updateMessage(@NotNull ChatMessage chatMessage) {
        msgListAdapter.updateMessage(chatMessage);
    }

    @Override
    public void scrollToBottom() {
        chatView.scrollToBottom();
    }

    @Override
    public void addToEnd(@NotNull List<ChatMessage> chatMessages) {
        msgListAdapter.addToEnd(chatMessages);
    }

    @Override
    public void finish() {
        Intent intent = new Intent();
        intent.putExtra(RouterConst.conv_id, presenter.getConv_id());
        setResult(RESULT_OK, intent);
        super.finish();
    }

    public static void startThis(Activity activity, String conv_id, ChatUser aimChatUser) {
        ARouter.getInstance()
                .build(RouterConst.ChatActivity)
                .withString(RouterConst.conv_id, conv_id)
                .withParcelable(RouterConst.aimChatUser, aimChatUser)
                .navigation(activity, RouterConst.chatActivityRequestCode);
    }

    public static void startThis(Activity activity, ChatUser aimChatUser) {
        startThis(activity, "", aimChatUser);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (RESULT_OK == resultCode) {
            if (requestCode == selectPhotoRequestCode) {
                //返回图片地址集合：如果你只需要获取图片的地址，可以用这个
                ArrayList<String> resultPaths = data.getStringArrayListExtra(EasyPhotos.RESULT_PATHS);
                presenter.uploadChatImages(resultPaths);
            }
        }
    }

    @Override
    public boolean onTouch(View view, MotionEvent motionEvent) {
        switch (motionEvent.getAction()) {
            case MotionEvent.ACTION_DOWN:
                if (chatInputView.getMenuState() == View.VISIBLE) {
                    chatInputView.dismissMenuLayout();
                }
                try {
                    View v = getCurrentFocus();
                    if (inputMethodManager != null && v != null) {
                        inputMethodManager.hideSoftInputFromWindow(v.getWindowToken(), 0);
                        mWindow.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
                        view.clearFocus();
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
                break;
            case MotionEvent.ACTION_UP:
                view.performClick();
                break;
            default:
        }
        return false;
    }

    //region sensor  screen headset
    @SuppressLint("InvalidWakeLockTag")
    private void registerProximitySensorListener() {
        try {
            mPowerManager = (PowerManager) getSystemService(POWER_SERVICE);
            mWakeLock = mPowerManager.newWakeLock(PowerManager.PROXIMITY_SCREEN_OFF_WAKE_LOCK, TAG);
            mSensorManager = (SensorManager) getSystemService(SENSOR_SERVICE);
            mSensor = mSensorManager.getDefaultSensor(Sensor.TYPE_PROXIMITY);
            mSensorManager.registerListener(this, mSensor, SensorManager.SENSOR_DELAY_NORMAL);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void onSensorChanged(SensorEvent event) {
        AudioManager audioManager = (AudioManager) getSystemService(AUDIO_SERVICE);
        try {
            if (audioManager.isBluetoothA2dpOn() || audioManager.isWiredHeadsetOn()) {
                return;
            }
            if (msgListAdapter.getMediaPlayer().isPlaying()) {
                float distance = event.values[0];
                if (distance >= mSensor.getMaximumRange()) {
                    msgListAdapter.setAudioPlayByEarPhone(0);
                    setScreenOn();
                } else {
                    msgListAdapter.setAudioPlayByEarPhone(2);
                    ViewHolderController.getInstance().replayVoice();
                    setScreenOff();
                }
            } else {
                if (mWakeLock != null && mWakeLock.isHeld()) {
                    mWakeLock.release();
                    mWakeLock = null;
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    private void setScreenOn() {
        if (mWakeLock != null) {
            mWakeLock.setReferenceCounted(false);
            mWakeLock.release();
            mWakeLock = null;
        }
    }

    @SuppressLint("InvalidWakeLockTag")
    private void setScreenOff() {
        if (mWakeLock == null) {
            mWakeLock = mPowerManager.newWakeLock(PowerManager.PROXIMITY_SCREEN_OFF_WAKE_LOCK, TAG);
        }
        mWakeLock.acquire();
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {

    }

    private class HeadsetDetectReceiver extends BroadcastReceiver {

        @Override
        public void onReceive(Context context, Intent intent) {
            if (intent.getAction().equals(Intent.ACTION_HEADSET_PLUG)) {
                if (intent.hasExtra("state")) {
                    int state = intent.getIntExtra("state", 0);
                    msgListAdapter.setAudioPlayByEarPhone(state);
                }
            }
        }
    }
    //endregion

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (menuClickListener != null) {
            menuClickListener.dispose();
        }
        unregisterReceiver(mReceiver);
        mSensorManager.unregisterListener(this);
        if (onCameraCallbackListener != null) {
            onCameraCallbackListener.disposable();
        }
        if (recordVoiceListener != null) {
            recordVoiceListener.disposable();
        }
        if (chatView != null) {
            chatView.dispose();
        }
    }
}
